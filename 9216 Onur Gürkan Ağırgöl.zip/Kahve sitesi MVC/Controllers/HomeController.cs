﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Kahve_sitesi_MVC.Models;

namespace Kahve_sitesi_MVC.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    [Route("/menu")]
    public IActionResult Menu()
    {
        return View();
    }

    [Route("/blog")]
    public IActionResult Blog()
    {
        return View();
    }

    [Route("/contact")]
    public IActionResult Contact()
    {
        return View();
    }

    [Route("/about")]
    public IActionResult About()
    {
        return View();
    }

     [Route("/cart")]
    public IActionResult Cart()
    {
        return View();
    }


     [Route("/shop")]
    public IActionResult Shop()
    {
        return View();
    }

     [Route("/services")]
    public IActionResult Services()
    {
        return View();
    }

    [Route("/product")]
    public IActionResult Product()
    {
        return View();
    }
    [Route("/checkout")]
    public IActionResult Checkout()
    {
        return View();
    }

    [Route("/room")]
    public IActionResult Room()
    {
        return View();
    }


    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
